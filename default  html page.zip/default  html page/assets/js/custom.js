// Button Rpplr effects JS Start
(function($) {
$(".ripple-effect").click(function(e){
    var rippler = $(this);
    if(rippler.find(".teffect").length === 0) {
        rippler.append("<span class='teffect'></span>");
    }
    var teffect = rippler.find(".teffect");
    teffect.removeClass("animate");
    if(!teffect.height() && !teffect.width())
    {
        var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
        teffect.css({height: d, width: d});
    }
    var x = e.pageX - rippler.offset().left - teffect.width()/2;
    var y = e.pageY - rippler.offset().top - teffect.height()/2;
    teffect.css({
        top: y+'px',
        left:x+'px'
    }).addClass("animate");
})
})(jQuery);
// Button Rpplr effects JS End

// Parallax  JS Start
function simpleParallax() {
	var scrolled = $(window).scrollTop() + 1;
	 $('.banner-default,.counter-feature').css('background-position', '0' + -(scrolled * 0.4) + 'px');
    }
    $(window).scroll(function (e) {
	 simpleParallax();
});
// Parallax  JS End

new WOW().init();