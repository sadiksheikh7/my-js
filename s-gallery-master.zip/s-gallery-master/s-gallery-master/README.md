S Gallery: A Responsive jQuery Gallery Plugin with CSS3 Animations (with touch/swipe support)
==================================



+ [Live demo](http://sarasoueidan.com/blog/s-gallery-responsive-jquery-gallery-plugin-with-css3-animations/demo/index.html)

+ [Blog post including how-to guide](http://sarasoueidan.com/blog/s-gallery-responsive-jquery-gallery-plugin-with-css3-animations/)

Licensed under [Creative Commons Attribution Non-Commercial](http://creativecommons.org/licenses/by-nc/4.0/) (CC BY-NC 4.0)

*Want to use it in a commercial project? Please [get in touch](mailto: contact@sarasoueidan.com).*
