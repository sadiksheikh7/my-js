// loaded fixed-sticky polyfill
// https://github.com/filamentgroup/fixed-sticky

$( '.sidebar' ).fixedsticky();