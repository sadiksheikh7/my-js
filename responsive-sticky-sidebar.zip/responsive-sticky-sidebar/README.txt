A Pen created at CodePen.io. You can find this one at http://codepen.io/jamesdarren/pen/ivmcH.

 Totally responsive layout where the sidebar switches between a normal and a fixed position.